// API key
const API_KEY = "pk.eyJ1IjoibG9ja2UzNiIsImEiOiJjam9sbnY2OHowNTd1M3FzOHVsc2duN2R4In0.ilnfrvun0Zc7NzXISIQZ2A";
